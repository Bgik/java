package tinkoff.finalvarstatic;

import java.util.LinkedList;
import java.util.List;

public class Var {

    //var a = "123";

    public static void main(String[] args) {
        var str = "123";
        var i = 1;
        var l = 1L;
        var d = 1D;
        var d2 = 1.0;

        var ints = new int[5];
    }
}
