package tinkoff.finalvarstatic;

import java.util.LinkedList;
import java.util.List;

public class Example {
    public static int common;
    public int x;

    public static void printCommon() {
        System.out.println(common);
    }
/*
    public static void printX() {
                System.out.println(x);
    }
 */
}
