package org.game.pretty.question;

public enum QuestionCategory {
    POP, ROCK, SCIENCE, SPORTS;
}
